from flask import Flask, request

app = Flask(__name__)

def process_input(input_value):
    if input_value == '94538':
        return 'cold'
    elif input_value == '98765':
        return 'warmer'
    else:
        return 'Invalid zipcode. Please try again.'

@app.route('/weather', methods=['GET'])
def get_response():
    input_value = request.args.get('zipcode')
    response = process_input(input_value)
    return response

# Example usage
if __name__ == '__main__':
    app.run(debug=True, port=5002)

