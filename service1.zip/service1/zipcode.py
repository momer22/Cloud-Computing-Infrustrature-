from flask import Flask, request

app = Flask(__name__)

def process_input(input_value):
    if input_value == 'fremont':
        return '94538'
    elif input_value == 'sanjose':
        return '98765'
    else:
        return 'Invalid city name. Please try again.'

@app.route('/zipcode', methods=['GET'])
def get_response():
    input_value = request.args.get('city')
    response = process_input(input_value)
    return response

# Example usage
if __name__ == '__main__':
    app.run(debug=True, port=5001)

